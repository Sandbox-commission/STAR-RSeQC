STAR-RSeQC Distribution Contents
==================================

Directory Structure:

  star-rseqc              Pre-compiled binary
  setup.sh                Interactive installer (main entry point)
  docker/
    ├── Dockerfile        Container definition
    ├── docker-compose.yml Docker Compose configuration
    └── .dockerignore     Docker build exclusions
  docs/
    ├── README.md         Full documentation
    ├── QUICK_START.md    Getting started guide
    └── TROUBLESHOOTING.md Problem solver
  INSTALL.txt             This installation guide
  VERSION.txt             Version and build information

Getting Started:

  1. Make sure setup.sh is executable:
     chmod +x setup.sh

  2. Run the installer:
     ./setup.sh

  3. Choose your installation method:
     a) Docker (recommended, fastest)
     b) Automatic mamba/conda installation
     c) Manual installation with web links

  4. Follow the interactive prompts

Notes:

  - Installation typically takes 10-30 minutes (depending on method)
  - Docker method is fastest if Docker is already installed
  - Automatic mamba installation requires ~2-3 GB download
  - Manual installation provides maximum control

System Requirements:

  - Linux x86_64 or macOS (with Docker)
  - 8+ GB RAM minimum, 32+ GB recommended
  - Internet connection for downloads
  - ~50 GB disk space minimum

Troubleshooting:

  See docs/TROUBLESHOOTING.md for common issues and solutions.

Support:

  - GitHub Issues: https://github.com/Sandbox-commission/STAR-RSeQC/issues
  - Documentation: docs/README.md

