# Quick Start

## Three Installation Options

### Option 1: Docker (Fastest, Recommended)
```bash
cd STAR-RSeQC-*
./setup.sh
# Select: 1 (Docker)
```

### Option 2: Automatic Setup (Mamba/Conda)
```bash
cd STAR-RSeQC-*
./setup.sh
# Select: 2 (Automatic)
```

### Option 3: Manual Installation
```bash
cd STAR-RSeQC-*
./setup.sh
# Select: 3 (Manual)
```

## Using the Binary Directly

If you've already installed dependencies:
```bash
./star-rseqc /path/to/fastq -o results
```

## Configuration

Edit `~/.config/star-rseqc/config.json`:
```json
{
  "genome_dir": "/path/to/star/index",
  "gtf": "/path/to/annotation.gtf",
  "star_env": "/path/to/conda/envs/star",
  "rseqc_env": "/path/to/conda/envs/rseqc",
  "samtools": "/path/to/samtools"
}
```

## Docker Usage

Build the image:
```bash
cd docker
docker build -t star-rseqc:latest .
```

Run analysis:
```bash
docker run --rm \
  -v /path/to/fastq:/data/input:ro \
  -v /path/to/output:/data/output \
  star-rseqc:latest \
  star-rseqc /data/input -o /data/output
```
