# Troubleshooting

## Docker Not Installed
Run the setup script and choose "Auto-install Docker" when prompted.

## Mamba/Conda Not Found
Run the setup script and choose "Automatic" for mamba installation.

## Binary Not in PATH
Add to your `.bashrc` or `.zshrc`:
```bash
export PATH="$HOME/.local/bin:$PATH"
```

## Config File Not Found
Create `~/.config/star-rseqc/config.json`:
```bash
mkdir -p ~/.config/star-rseqc
# Edit with your paths
nano ~/.config/star-rseqc/config.json
```

## STAR Environment Not Found
Verify conda environments:
```bash
conda env list
```

If missing, re-run setup.sh and choose automatic installation.

## Permission Denied
Make setup script executable:
```bash
chmod +x setup.sh
```

Make binary executable:
```bash
chmod +x star-rseqc
```

## Docker Permission Issues
Add your user to docker group:
```bash
sudo usermod -aG docker $USER
newgrp docker
```
